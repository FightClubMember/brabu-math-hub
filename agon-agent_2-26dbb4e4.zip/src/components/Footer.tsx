import { useState } from 'react'
import { usePortal } from '../context/PortalContext'
import AuthModal from './AuthModal'

const Footer = () => {
  const [authOpen, setAuthOpen] = useState(false)
  const { notifications } = usePortal()

  return (
    <footer className="relative border-t border-white/10 bg-slate-950/80 py-8">
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-4 px-6 text-sm text-white/60">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <p>© 2025 BRABU FYUGP Unified Portal. Crafted for 8 semesters of excellence.</p>
          <p>Urgent Alerts Active: {notifications.length}</p>
        </div>
        <p>Optimized for offline-ready PWA usage across mobile and desktop devices.</p>
      </div>
      <button
        onClick={() => setAuthOpen(true)}
        className="absolute bottom-0 right-0 h-[10px] w-[10px] cursor-pointer bg-transparent"
        aria-label="Hidden admin trigger"
      />
      <AuthModal open={authOpen} onClose={() => setAuthOpen(false)} />
    </footer>
  )
}

export default Footer
