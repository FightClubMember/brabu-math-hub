import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { Search } from 'lucide-react'
import GlassCard from './GlassCard'
import { usePortal } from '../context/PortalContext'

interface SearchModalProps {
  open: boolean
  onClose: () => void
}

const SearchModal = ({ open, onClose }: SearchModalProps) => {
  const { portalData } = usePortal()
  const [query, setQuery] = useState('')

  const results = useMemo(() => {
    if (!query.trim()) return []
    const lowered = query.toLowerCase()
    const matches: {
      title: string
      subtitle: string
      path: string
    }[] = []

    portalData.faculties.forEach((faculty) => {
      faculty.majors.forEach((major) => {
        major.semesters.forEach((semester) => {
          Object.entries(semester.categories).forEach(([category, courses]) => {
            courses.forEach((course) => {
              const haystack = `${course.title} ${course.description} ${course.topics.join(' ')}`.toLowerCase()
              if (haystack.includes(lowered)) {
                matches.push({
                  title: course.title,
                  subtitle: `${faculty.title} • ${major.title} • Semester ${semester.number} • ${category}`,
                  path: `/${faculty.slug}/${major.slug}/sem-${semester.number}`,
                })
              }
            })
          })
        })
      })
    })

    return matches.slice(0, 10)
  }, [portalData, query])

  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-slate-950/80 px-4 pt-24">
      <GlassCard className="w-full max-w-2xl">
        <div className="flex items-center gap-3">
          <Search className="h-5 w-5 text-white/60" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search courses, topics, theorems, or subjects"
            className="w-full bg-transparent text-white placeholder:text-white/40 focus:outline-none"
          />
        </div>
        <div className="mt-6 space-y-3">
          {results.length === 0 && query && (
            <p className="text-sm text-white/50">No results found. Try another keyword.</p>
          )}
          {results.map((result) => (
            <Link
              key={result.path + result.title}
              to={result.path}
              onClick={onClose}
              className="block rounded-2xl border border-white/10 bg-white/5 px-4 py-3 transition hover:border-[var(--accent)]"
            >
              <p className="text-sm font-semibold text-white">{result.title}</p>
              <p className="text-xs text-white/50">{result.subtitle}</p>
            </Link>
          ))}
        </div>
        <button
          onClick={onClose}
          className="mt-6 text-xs text-white/40 hover:text-white"
        >
          Press Esc to close
        </button>
      </GlassCard>
    </div>
  )
}

export default SearchModal
