import { motion, AnimatePresence } from 'framer-motion'
import { useMemo, useState } from 'react'
import GlassCard from './GlassCard'
import { usePortal } from '../context/PortalContext'
import type { Notice, NoticeCategory } from '../data/noticeTypes'

interface NotificationHubProps {
  open: boolean
  onClose: () => void
}

const iconMap: Record<Notice['icon'], string> = {
  exam: '📝',
  result: '🎓',
  holiday: '🌴',
  update: '📌',
}

const tabs: Array<{ id: 'all' | NoticeCategory; label: string; accent: string }> = [
  { id: 'all', label: 'All', accent: 'bg-white/30' },
  { id: 'exams', label: 'Exams', accent: 'bg-red-500' },
  { id: 'campus', label: 'Campus', accent: 'bg-blue-500' },
]

const NotificationHub = ({ open, onClose }: NotificationHubProps) => {
  const { notices, removeNotice, theme } = usePortal()
  const [activeTab, setActiveTab] = useState<'all' | NoticeCategory>('all')

  const filtered = useMemo(() => {
    const scoped = notices.filter((notice) => notice.target === 'all' || notice.target === theme)
    if (activeTab === 'all') return scoped
    return scoped.filter((notice) => notice.category === activeTab)
  }, [activeTab, notices, theme])

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex justify-end bg-slate-950/50 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className="h-full w-full max-w-lg overflow-y-auto border-l border-white/10 bg-slate-950/70 px-6 py-8"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 260, damping: 28 }}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs uppercase tracking-[0.3em] text-white/50">Live Notices</p>
                <h2 className="mt-2 text-2xl font-semibold text-white">Notification Hub</h2>
              </div>
              <button
                onClick={onClose}
                className="rounded-full border border-white/20 px-4 py-2 text-xs text-white/70 transition hover:text-white"
              >
                Close
              </button>
            </div>

            <div className="mt-6 flex gap-2">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-2 rounded-full border px-4 py-2 text-xs font-semibold transition ${
                    activeTab === tab.id
                      ? 'border-white/40 bg-white/10 text-white'
                      : 'border-white/10 text-white/60 hover:text-white'
                  }`}
                >
                  <span className={`h-2 w-2 rounded-full ${tab.accent}`} />
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="mt-6 space-y-4">
              {filtered.length === 0 && (
                <p className="text-sm text-white/50">No notices in this category.</p>
              )}
              {filtered.map((notice) => (
                <motion.div
                  key={notice.id}
                  drag="x"
                  dragConstraints={{ left: 0, right: 0 }}
                  onDragEnd={(_, info) => {
                    if (info.offset.x > 120) {
                      removeNotice(notice.id)
                    }
                  }}
                  whileHover={{ y: -4 }}
                  className="cursor-grab"
                >
                  <GlassCard
                    className={`border-l-4 bg-white/10 backdrop-blur-md ${
                      notice.priority === 'critical'
                        ? 'border-red-500/80 bg-gradient-to-r from-red-500/20 via-red-500/5 to-transparent shadow-[0_0_24px_rgba(239,68,68,0.45)]'
                        : 'border-blue-400/60'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{iconMap[notice.icon]}</span>
                        <div>
                          <p className="text-sm font-semibold text-white">{notice.title}</p>
                          <p className="mt-1 text-xs text-white/60">{notice.description}</p>
                        </div>
                      </div>
                      <span className="text-[10px] uppercase text-white/40">{notice.timestamp}</span>
                    </div>
                    <div className="mt-4 flex items-center justify-between">
                      <span className="rounded-full bg-white/10 px-3 py-1 text-[10px] uppercase text-white/50">
                        {notice.category}
                      </span>
                      <a
                        href={notice.actionLink}
                        className="rounded-full bg-white/15 px-3 py-1 text-xs font-semibold text-white/80 transition hover:bg-white/25"
                      >
                        {notice.actionLabel}
                      </a>
                    </div>
                  </GlassCard>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

export default NotificationHub
