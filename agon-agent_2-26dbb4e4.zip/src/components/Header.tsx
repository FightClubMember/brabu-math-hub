import { Bell, Command, GraduationCap, LayoutGrid } from 'lucide-react'
import { Link, NavLink } from 'react-router-dom'
import { usePortal } from '../context/PortalContext'
import { facultyColors } from '../data/portalData'

interface HeaderProps {
  onSearchOpen: () => void
  onNotificationsOpen: () => void
}

const Header = ({ onSearchOpen, onNotificationsOpen }: HeaderProps) => {
  const { theme, setTheme, notices } = usePortal()

  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-slate-950/70 backdrop-blur-2xl">
      <div className="mx-auto flex w-full max-w-6xl flex-wrap items-center justify-between gap-4 px-6 py-4">
        <Link to="/" className="flex items-center gap-3 text-lg font-semibold text-white">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-white/10">
            <GraduationCap className="h-5 w-5 text-[var(--accent)]" />
          </div>
          <div>
            <p className="text-sm uppercase tracking-[0.2em] text-white/50">BRABU</p>
            <p className="text-base font-semibold">FYUGP Unified Portal</p>
          </div>
        </Link>
        <nav className="flex flex-wrap items-center gap-4 text-sm text-white/70">
          <NavLink
            to="/"
            className={({ isActive }) =>
              `flex items-center gap-2 rounded-full px-3 py-2 transition ${
                isActive ? 'bg-white/10 text-white' : 'hover:text-white'
              }`
            }
          >
            <LayoutGrid className="h-4 w-4" />
            Overview
          </NavLink>
          <NavLink
            to="/pyq"
            className={({ isActive }) =>
              `rounded-full px-3 py-2 transition ${
                isActive ? 'bg-white/10 text-white' : 'hover:text-white'
              }`
            }
          >
            PYQ Vault
          </NavLink>
          <button
            onClick={onSearchOpen}
            className="flex items-center gap-2 rounded-full border border-white/10 px-3 py-2 text-white/70 transition hover:text-white"
          >
            <Command className="h-4 w-4" />
            Command + K
          </button>
          <button
            onClick={onNotificationsOpen}
            className="flex items-center gap-2 rounded-full border border-white/10 px-3 py-2 text-white/70 transition hover:text-white"
          >
            <Bell className="h-4 w-4" />
            Live Notices
          </button>
        </nav>
        <div className="flex items-center gap-3">
          <button
            onClick={onNotificationsOpen}
            className="relative flex h-10 w-10 items-center justify-center rounded-full border border-white/15 bg-white/5 text-white/80 transition hover:text-white"
            aria-label="Open notifications hub"
          >
            <Bell className="h-5 w-5" />
            <span className="absolute -right-1 -top-1 flex h-4 w-4 items-center justify-center">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-emerald-400 opacity-60" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-emerald-400" />
            </span>
            <span className="absolute -bottom-3 right-1 text-[9px] font-semibold uppercase text-emerald-300">
              Live
            </span>
            {notices.length > 0 && (
              <span className="absolute -bottom-1 -right-2 rounded-full bg-red-500 px-1 text-[10px] text-white">
                {notices.length}
              </span>
            )}
          </button>
          {Object.entries(facultyColors).map(([key, value]) => (
            <button
              key={key}
              onClick={() => setTheme(key as keyof typeof facultyColors)}
              className={`h-9 w-9 rounded-full border transition ${
                theme === key ? 'scale-105 border-white/60' : 'border-white/20'
              }`}
              style={{ background: value.accent }}
              aria-label={`Switch to ${key} theme`}
            />
          ))}
        </div>
      </div>
    </header>
  )
}

export default Header
