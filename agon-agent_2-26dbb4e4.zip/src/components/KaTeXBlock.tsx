import katex from 'katex'

interface KaTeXBlockProps {
  latex: string
}

const KaTeXBlock = ({ latex }: KaTeXBlockProps) => {
  const html = katex.renderToString(latex, { throwOnError: false, displayMode: true, output: 'html' })
  return (
    <div
      className="overflow-x-auto rounded-2xl border border-white/10 bg-white/5 p-4 text-white"
      dangerouslySetInnerHTML={{ __html: html }}
    />
  )
}

export default KaTeXBlock
