import { AlertTriangle } from 'lucide-react'
import { usePortal } from '../context/PortalContext'

const RedTicker = () => {
  const { notifications } = usePortal()
  if (notifications.length === 0) return null

  return (
    <div className="border-b border-red-500/40 bg-red-500/10">
      <div className="mx-auto flex w-full max-w-6xl items-center gap-3 px-6 py-2 text-sm text-red-200">
        <AlertTriangle className="h-4 w-4" />
        <div className="flex flex-1 flex-wrap gap-4">
          {notifications.map((note, index) => (
            <span key={note + index} className="whitespace-nowrap">
              {note}
            </span>
          ))}
        </div>
      </div>
    </div>
  )
}

export default RedTicker
