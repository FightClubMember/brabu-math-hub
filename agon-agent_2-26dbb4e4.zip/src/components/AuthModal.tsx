import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import GlassCard from './GlassCard'

interface AuthModalProps {
  open: boolean
  onClose: () => void
}

const AuthModal = ({ open, onClose }: AuthModalProps) => {
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const navigate = useNavigate()

  if (!open) return null

  const handleSubmit = () => {
    if (password === 'Himanshu@01') {
      onClose()
      navigate('/secret-admin-panel')
      setPassword('')
      setError('')
    } else {
      setError('Access denied. Invalid authentication key.')
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 px-4">
      <GlassCard className="w-full max-w-md">
        <h2 className="text-xl font-semibold text-white">System Authentication</h2>
        <p className="mt-2 text-sm text-white/60">
          Enter the administrative key to access the secure portal.
        </p>
        <input
          type="password"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          placeholder="Authentication Key"
          className="mt-4 w-full rounded-2xl border border-white/15 bg-white/5 px-4 py-3 text-white placeholder:text-white/40 focus:border-[var(--accent)] focus:outline-none"
        />
        {error && <p className="mt-2 text-sm text-red-400">{error}</p>}
        <div className="mt-6 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="rounded-full border border-white/15 px-4 py-2 text-sm text-white/70 transition hover:text-white"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            className="rounded-full bg-[var(--accent)] px-4 py-2 text-sm font-semibold text-white shadow-lg shadow-[var(--accent)]/30"
          >
            Authenticate
          </button>
        </div>
      </GlassCard>
    </div>
  )
}

export default AuthModal
