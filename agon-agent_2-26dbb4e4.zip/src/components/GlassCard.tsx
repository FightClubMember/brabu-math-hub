import { cn } from '../lib/utils'

interface GlassCardProps {
  className?: string
  children: React.ReactNode
}

const GlassCard = ({ className, children }: GlassCardProps) => (
  <div
    className={cn(
      'rounded-3xl border border-white/15 bg-white/5 p-6 shadow-[0_20px_60px_-20px_rgba(15,23,42,0.8)] backdrop-blur-2xl',
      className,
    )}
  >
    {children}
  </div>
)

export default GlassCard
