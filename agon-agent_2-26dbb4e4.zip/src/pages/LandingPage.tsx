import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import GlassCard from '../components/GlassCard'
import { facultyColors } from '../data/portalData'

const facultyCards = [
  {
    slug: 'science',
    title: 'Science',
    description: 'Explore STEM disciplines with labs, models, and rigorous theory.',
  },
  {
    slug: 'arts',
    title: 'Arts',
    description: 'Dive into humanities, creativity, and critical narratives.',
  },
  {
    slug: 'commerce',
    title: 'Commerce',
    description: 'Master finance, management, and market analytics.',
  },
]

const LandingPage = () => (
  <div className="mx-auto w-full max-w-6xl px-6 py-12">
    <div className="grid gap-8 lg:grid-cols-[1.3fr_1fr]">
      <div className="space-y-6">
        <p className="text-sm uppercase tracking-[0.4em] text-white/40">BRABU FYUGP Unified Portal</p>
        <h1 className="text-4xl font-semibold text-white md:text-5xl">
          A unified, glassmorphic academic cockpit for all 8 semesters.
        </h1>
        <p className="text-lg text-white/60">
          Navigate majors, minors, multidisciplinary learning, and skill-based modules. Search every course,
          access PYQs, and engage with interactive tools built for FYUGP learners.
        </p>
        <div className="flex flex-wrap gap-4">
          <Link
            to="/science"
            className="rounded-full bg-[var(--accent)] px-5 py-3 text-sm font-semibold text-white shadow-lg shadow-[var(--accent)]/30"
          >
            Explore Science Portal
          </Link>
          <Link
            to="/pyq"
            className="rounded-full border border-white/20 px-5 py-3 text-sm text-white/70 transition hover:text-white"
          >
            View PYQ Vault
          </Link>
        </div>
      </div>
      <GlassCard className="flex flex-col justify-between gap-6">
        <div>
          <p className="text-sm text-white/60">Smart Highlights</p>
          <h2 className="mt-2 text-2xl font-semibold text-white">Command + K Global Search</h2>
          <p className="mt-2 text-sm text-white/60">
            Find any theorem, course, or skill module instantly with the unified search palette.
          </p>
        </div>
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-white/40">PWA Ready</p>
          <p className="mt-2 text-sm text-white/60">
            Install the portal on your phone for instant offline access to syllabus, PYQs, and notes.
          </p>
        </div>
      </GlassCard>
    </div>

    <div className="mt-12 grid gap-6 md:grid-cols-3">
      {facultyCards.map((card, index) => (
        <motion.div
          key={card.slug}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: index * 0.15, duration: 0.5 }}
        >
          <Link to={`/${card.slug}`}>
            <GlassCard className="group h-full transition hover:-translate-y-2">
              <div
                className="h-14 w-14 rounded-2xl"
                style={{ background: facultyColors[card.slug].accent }}
              />
              <h3 className="mt-5 text-xl font-semibold text-white">{card.title}</h3>
              <p className="mt-2 text-sm text-white/60">{card.description}</p>
              <p className="mt-6 text-xs uppercase tracking-[0.3em] text-white/40">
                Enter {card.title} Faculty
              </p>
            </GlassCard>
          </Link>
        </motion.div>
      ))}
    </div>
  </div>
)

export default LandingPage
