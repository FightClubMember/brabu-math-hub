import GlassCard from '../components/GlassCard'

const pyqData = [
  {
    year: '2024',
    subjects: ['Leibniz Theorem', 'Financial Accounting', 'Classical Mechanics', 'Modern Indian History'],
  },
  {
    year: '2023',
    subjects: ['Real Analysis', 'Business Law', 'World Literature', 'Microeconomics'],
  },
  {
    year: '2022',
    subjects: ['Vector Calculus', 'Corporate Finance', 'Political Theory', 'Organic Chemistry'],
  },
]

const PYQPage = () => (
  <div className="mx-auto w-full max-w-6xl px-6 py-12">
    <div className="space-y-6">
      <div>
        <p className="text-sm uppercase tracking-[0.3em] text-white/40">PYQ Vault</p>
        <h1 className="mt-2 text-3xl font-semibold text-white">Previous Year Questions Archive</h1>
        <p className="mt-3 text-sm text-white/60">
          Browse semester-wise PYQs curated for Science, Arts, and Commerce students.
        </p>
      </div>
      <div className="grid gap-6 md:grid-cols-3">
        {pyqData.map((entry) => (
          <GlassCard key={entry.year}>
            <h2 className="text-lg font-semibold text-white">{entry.year}</h2>
            <ul className="mt-3 space-y-2 text-sm text-white/60">
              {entry.subjects.map((subject) => (
                <li key={subject} className="rounded-xl border border-white/10 bg-white/5 px-3 py-2">
                  {subject}
                </li>
              ))}
            </ul>
            <button className="mt-4 w-full rounded-full bg-[var(--accent)] px-4 py-2 text-sm font-semibold text-white">
              Download PDF Bundle
            </button>
          </GlassCard>
        ))}
      </div>
    </div>
  </div>
)

export default PYQPage
