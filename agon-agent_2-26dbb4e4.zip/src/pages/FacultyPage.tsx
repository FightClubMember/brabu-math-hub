import { Link, useParams } from 'react-router-dom'
import { useEffect } from 'react'
import { motion } from 'framer-motion'
import GlassCard from '../components/GlassCard'
import { usePortal } from '../context/PortalContext'

const FacultyPage = () => {
  const { faculty } = useParams()
  const { portalData, setTheme } = usePortal()
  const selected = portalData.faculties.find((item) => item.slug === faculty)

  if (!selected) {
    return (
      <div className="mx-auto max-w-4xl px-6 py-12 text-white">
        Faculty not found.
      </div>
    )
  }

  useEffect(() => {
    setTheme(selected.slug)
  }, [selected.slug, setTheme])

  return (
    <div className="mx-auto w-full max-w-6xl px-6 py-12">
      <div className="flex flex-col gap-6">
        <div>
          <p className="text-sm uppercase tracking-[0.3em] text-white/40">{selected.title}</p>
          <h1 className="mt-2 text-3xl font-semibold text-white">{selected.description}</h1>
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          {selected.majors.map((major, index) => (
            <motion.div
              key={major.slug}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <GlassCard>
                <h3 className="text-xl font-semibold text-white">{major.title}</h3>
                <p className="mt-2 text-sm text-white/60">{major.description}</p>
                <div className="mt-4 flex flex-wrap gap-2">
                  {major.semesters.map((semester) => (
                    <Link
                      key={semester.number}
                      to={`/${selected.slug}/${major.slug}/sem-${semester.number}`}
                      className="rounded-full border border-white/15 px-3 py-1 text-xs text-white/70 transition hover:border-[var(--accent)]"
                    >
                      Sem {semester.number}
                    </Link>
                  ))}
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default FacultyPage
