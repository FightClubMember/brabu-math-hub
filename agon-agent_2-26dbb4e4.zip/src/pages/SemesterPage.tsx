import { motion } from 'framer-motion'
import { useEffect, useMemo } from 'react'
import { Link, useParams } from 'react-router-dom'
import GlassCard from '../components/GlassCard'
import KaTeXBlock from '../components/KaTeXBlock'
import { usePortal } from '../context/PortalContext'
import type { CourseCategory } from '../data/portalData'

const categoryLabels: Record<CourseCategory, string> = {
  MJC: 'Major Core',
  MIC: 'Minor Core',
  MDC: 'Multidisciplinary',
  AEC: 'Ability Enhancement',
  SEC: 'Skill Enhancement',
  VAC: 'Value Added',
}

const SemesterPage = () => {
  const { faculty, major, semester } = useParams()
  const { portalData, setTheme } = usePortal()
  const selectedFaculty = portalData.faculties.find((item) => item.slug === faculty)
  const selectedMajor = selectedFaculty?.majors.find((item) => item.slug === major)
  const semesterNumber = Number(semester?.replace('sem-', ''))
  const selectedSemester = selectedMajor?.semesters.find((item) => item.number === semesterNumber)

  if (!selectedFaculty || !selectedMajor || !selectedSemester) {
    return (
      <div className="mx-auto max-w-4xl px-6 py-12 text-white">
        Semester not found. Return to <Link to="/">home</Link>.
      </div>
    )
  }

  useEffect(() => {
    setTheme(selectedFaculty.slug)
  }, [selectedFaculty.slug, setTheme])

  const categories = useMemo(() => Object.entries(selectedSemester.categories), [selectedSemester])

  return (
    <div className="mx-auto w-full max-w-6xl px-6 py-12">
      <div className="flex flex-col gap-6">
        <div className="space-y-3">
          <p className="text-sm uppercase tracking-[0.3em] text-white/40">
            {selectedFaculty.title} • {selectedMajor.title}
          </p>
          <h1 className="text-3xl font-semibold text-white">
            Semester {selectedSemester.number}: {selectedSemester.focus}
          </h1>
        </div>

        {selectedSemester.mathematicsHighlight && (
          <GlassCard>
            <h2 className="text-lg font-semibold text-white">Mathematics Spotlight</h2>
            <p className="mt-2 text-sm text-white/60">Rendered with KaTeX for crisp, copyable formulas.</p>
            <div className="mt-4">
              <KaTeXBlock latex={selectedSemester.mathematicsHighlight} />
            </div>
          </GlassCard>
        )}

        {selectedMajor.slug === 'mathematics' && selectedSemester.number <= 2 && (
          <GlassCard>
            <h2 className="text-lg font-semibold text-white">Desmos Geometry Lab</h2>
            <p className="mt-2 text-sm text-white/60">
              Interactive graphing for geometry and analytic visualization.
            </p>
            <div className="mt-4 aspect-video w-full overflow-hidden rounded-2xl border border-white/10">
              <iframe
                title="Desmos Calculator"
                src="https://www.desmos.com/calculator"
                className="h-full w-full"
              />
            </div>
          </GlassCard>
        )}

        <div className="grid gap-6">
          {categories.map(([categoryKey, courses], index) => (
            <motion.div
              key={categoryKey}
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <GlassCard>
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <h2 className="text-lg font-semibold text-white">
                    {categoryLabels[categoryKey as CourseCategory]}
                  </h2>
                  <span className="rounded-full border border-white/20 px-3 py-1 text-xs text-white/70">
                    {categoryKey}
                  </span>
                </div>
                <div className="mt-4 grid gap-4 md:grid-cols-2">
                  {courses.map((course) => (
                    <div
                      key={course.code}
                      className="rounded-2xl border border-white/10 bg-white/5 p-4"
                    >
                      <div className="flex items-center justify-between">
                        <p className="text-xs uppercase tracking-[0.2em] text-white/40">{course.code}</p>
                        <span className="text-xs text-white/40">{course.topics.length} topics</span>
                      </div>
                      <h3 className="mt-2 text-sm font-semibold text-white">{course.title}</h3>
                      <p className="mt-2 text-xs text-white/60">{course.description}</p>
                      <div className="mt-3 flex flex-wrap gap-2">
                        {course.topics.map((topic) => (
                          <span
                            key={topic}
                            className="rounded-full border border-white/10 px-2 py-1 text-[11px] text-white/60"
                          >
                            {topic}
                          </span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </GlassCard>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default SemesterPage
