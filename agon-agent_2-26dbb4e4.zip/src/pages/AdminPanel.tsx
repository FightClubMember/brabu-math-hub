import { useMemo, useState } from 'react'
import GlassCard from '../components/GlassCard'
import { usePortal } from '../context/PortalContext'
import type { Notice, NoticePriority, NoticeTarget, NoticeIcon } from '../data/noticeTypes'

const AdminPanel = () => {
  const {
    portalData,
    setPortalData,
    addNotification,
    notifications,
    uploads,
    addUploads,
    removeNotification,
    broadcastNotice,
  } = usePortal()
  const [jsonDraft, setJsonDraft] = useState(JSON.stringify(portalData, null, 2))
  const [message, setMessage] = useState('')
  const [status, setStatus] = useState('')
  const [broadcastTitle, setBroadcastTitle] = useState('')
  const [broadcastMessage, setBroadcastMessage] = useState('')
  const [broadcastPriority, setBroadcastPriority] = useState<NoticePriority>('critical')
  const [broadcastTarget, setBroadcastTarget] = useState<NoticeTarget>('all')
  const [broadcastStatus, setBroadcastStatus] = useState('')

  const iconByPriority = useMemo<Record<NoticePriority, NoticeIcon>>(
    () => ({
      critical: 'exam',
      info: 'update',
    }),
    [],
  )

  const handleSave = () => {
    try {
      const parsed = JSON.parse(jsonDraft)
      setPortalData(parsed)
      setStatus('Syllabus data updated successfully.')
    } catch {
      setStatus('Invalid JSON format. Please validate before saving.')
    }
  }

  const handleUpload = (files: FileList | null) => {
    if (!files) return
    const items = Array.from(files).map((file) => ({ name: file.name, size: file.size }))
    addUploads(items)
  }

  const handleAddNotification = () => {
    if (!message.trim()) return
    addNotification(message)
    setMessage('')
  }

  const handleBroadcast = () => {
    if (!broadcastTitle.trim() || !broadcastMessage.trim()) return
    const newNotice: Notice = {
      id: `notice-${Date.now()}`,
      title: broadcastTitle,
      description: broadcastMessage,
      category: 'exams',
      priority: broadcastPriority,
      target: broadcastTarget,
      timestamp: 'Just now',
      actionLabel: broadcastPriority === 'critical' ? 'Open' : 'View Update',
      actionLink: '#',
      icon: iconByPriority[broadcastPriority] as Notice['icon'],
    }
    broadcastNotice(newNotice)
    setBroadcastStatus('Broadcast queued for students instantly.')
    setBroadcastTitle('')
    setBroadcastMessage('')
  }

  return (
    <div className="mx-auto w-full max-w-6xl px-6 py-12">
      <div className="space-y-8">
        <div>
          <p className="text-sm uppercase tracking-[0.3em] text-white/40">Secret Admin Panel</p>
          <h1 className="mt-2 text-3xl font-semibold text-white">Live Academic Control Center</h1>
          <p className="mt-3 text-sm text-white/60">
            Update syllabus JSON, upload PDF notes, and broadcast urgent exam notifications.
          </p>
        </div>

        <div className="grid gap-6 lg:grid-cols-2">
          <GlassCard>
            <h2 className="text-lg font-semibold text-white">Syllabus JSON Editor</h2>
            <textarea
              value={jsonDraft}
              onChange={(event) => setJsonDraft(event.target.value)}
              className="mt-4 h-80 w-full rounded-2xl border border-white/10 bg-white/5 p-4 text-xs text-white/70 focus:border-[var(--accent)] focus:outline-none"
            />
            {status && <p className="mt-3 text-xs text-white/60">{status}</p>}
            <button
              onClick={handleSave}
              className="mt-4 rounded-full bg-[var(--accent)] px-4 py-2 text-sm font-semibold text-white"
            >
              Save Updates
            </button>
          </GlassCard>

          <div className="space-y-6">
            <GlassCard>
              <h2 className="text-lg font-semibold text-white">Upload PDF Notes</h2>
              <input
                type="file"
                accept="application/pdf"
                multiple
                onChange={(event) => handleUpload(event.target.files)}
                className="mt-4 w-full text-sm text-white/60"
              />
              <div className="mt-4 space-y-2 text-xs text-white/60">
                {uploads.length === 0 && <p>No uploads yet.</p>}
                {uploads.map((file) => (
                  <div
                    key={file.name}
                    className="flex items-center justify-between rounded-xl border border-white/10 bg-white/5 px-3 py-2"
                  >
                    <span>{file.name}</span>
                    <span>{Math.round(file.size / 1024)} KB</span>
                  </div>
                ))}
              </div>
            </GlassCard>

            <GlassCard>
              <h2 className="text-lg font-semibold text-white">Red Ticker Notifications</h2>
              <div className="mt-4 flex gap-3">
                <input
                  value={message}
                  onChange={(event) => setMessage(event.target.value)}
                  placeholder="Enter urgent exam notification"
                  className="flex-1 rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm text-white/70 focus:border-[var(--accent)] focus:outline-none"
                />
                <button
                  onClick={handleAddNotification}
                  className="rounded-full bg-[var(--accent)] px-4 py-2 text-sm font-semibold text-white"
                >
                  Post
                </button>
              </div>
              <div className="mt-4 space-y-2 text-xs text-white/60">
                {notifications.map((note, index) => (
                  <div
                    key={note + index}
                    className="flex items-center justify-between rounded-xl border border-white/10 bg-white/5 px-3 py-2"
                  >
                    <span>{note}</span>
                    <button
                      onClick={() => removeNotification(index)}
                      className="text-xs text-red-300"
                    >
                      Remove
                    </button>
                  </div>
                ))}
              </div>
            </GlassCard>

            <GlassCard>
              <h2 className="text-lg font-semibold text-white">Broadcast Center</h2>
              <p className="mt-2 text-xs text-white/60">
                Compose priority alerts for the notification hub.
              </p>
              <div className="mt-4 space-y-3">
                <input
                  value={broadcastTitle}
                  onChange={(event) => setBroadcastTitle(event.target.value)}
                  placeholder="Alert title"
                  className="w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm text-white/70 focus:border-[var(--accent)] focus:outline-none"
                />
                <textarea
                  value={broadcastMessage}
                  onChange={(event) => setBroadcastMessage(event.target.value)}
                  placeholder="Alert description"
                  className="h-24 w-full rounded-2xl border border-white/10 bg-white/5 px-4 py-2 text-sm text-white/70 focus:border-[var(--accent)] focus:outline-none"
                />
                <div className="flex flex-wrap gap-2">
                  {(['critical', 'info'] as NoticePriority[]).map((level) => (
                    <button
                      key={level}
                      onClick={() => setBroadcastPriority(level)}
                      className={`rounded-full border px-4 py-2 text-xs font-semibold transition ${
                        broadcastPriority === level
                          ? 'border-white/40 bg-white/10 text-white'
                          : 'border-white/10 text-white/60'
                      }`}
                    >
                      {level === 'critical' ? 'High Priority' : 'Standard'}
                    </button>
                  ))}
                </div>
                <div className="flex flex-wrap gap-2">
                  {(['all', 'science', 'arts', 'commerce'] as NoticeTarget[]).map((target) => (
                    <button
                      key={target}
                      onClick={() => setBroadcastTarget(target)}
                      className={`rounded-full border px-4 py-2 text-xs font-semibold transition ${
                        broadcastTarget === target
                          ? 'border-white/40 bg-white/10 text-white'
                          : 'border-white/10 text-white/60'
                      }`}
                    >
                      {target.toUpperCase()}
                    </button>
                  ))}
                </div>
                <button
                  onClick={handleBroadcast}
                  className="rounded-full bg-[var(--accent)] px-4 py-2 text-sm font-semibold text-white"
                >
                  Send Broadcast
                </button>
                {broadcastStatus && <p className="text-xs text-white/60">{broadcastStatus}</p>}
              </div>
              <p className="mt-3 text-[10px] text-white/40">
                GitHub sync requires server-side credentials and is simulated locally in this build.
              </p>
            </GlassCard>
          </div>
        </div>
      </div>
    </div>
  )
}

export default AdminPanel
