import { useEffect, useState } from 'react'
import { Route, Routes, useLocation } from 'react-router-dom'
import Header from './components/Header'
import Footer from './components/Footer'
import RedTicker from './components/RedTicker'
import SearchModal from './components/SearchModal'
import NotificationHub from './components/NotificationHub'
import LandingPage from './pages/LandingPage'
import FacultyPage from './pages/FacultyPage'
import SemesterPage from './pages/SemesterPage'
import PYQPage from './pages/PYQPage'
import AdminPanel from './pages/AdminPanel'

const App = () => {
  const [searchOpen, setSearchOpen] = useState(false)
  const [notificationsOpen, setNotificationsOpen] = useState(false)
  const location = useLocation()

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault()
        setSearchOpen(true)
      }
      if (event.key === 'Escape') {
        setSearchOpen(false)
        setNotificationsOpen(false)
      }
    }
    window.addEventListener('keydown', handler)
    return () => window.removeEventListener('keydown', handler)
  }, [])

  useEffect(() => {
    setSearchOpen(false)
    setNotificationsOpen(false)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }, [location.pathname])

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <RedTicker />
      <Header
        onSearchOpen={() => setSearchOpen(true)}
        onNotificationsOpen={() => setNotificationsOpen(true)}
      />
      <main className="min-h-[70vh]">
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/pyq" element={<PYQPage />} />
          <Route path="/secret-admin-panel" element={<AdminPanel />} />
          <Route path="/:faculty/:major/:semester" element={<SemesterPage />} />
          <Route path="/:faculty" element={<FacultyPage />} />
        </Routes>
      </main>
      <Footer />
      <SearchModal open={searchOpen} onClose={() => setSearchOpen(false)} />
      <NotificationHub open={notificationsOpen} onClose={() => setNotificationsOpen(false)} />
    </div>
  )
}

export default App
