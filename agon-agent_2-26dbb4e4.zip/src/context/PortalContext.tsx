import React, { createContext, useContext, useEffect, useMemo, useState } from 'react'
import { basePortalData, facultyColors } from '../data/portalData'
import type { PortalData } from '../data/portalData'
import type { Notice } from '../data/noticeTypes'

interface PortalContextValue {
  portalData: PortalData
  setPortalData: (data: PortalData) => void
  theme: keyof typeof facultyColors
  setTheme: (theme: keyof typeof facultyColors) => void
  notifications: string[]
  addNotification: (message: string) => void
  removeNotification: (index: number) => void
  notices: Notice[]
  broadcastNotice: (notice: Notice) => void
  removeNotice: (id: string) => void
  uploads: { name: string; size: number }[]
  addUploads: (files: { name: string; size: number }[]) => void
}

const PortalContext = createContext<PortalContextValue | null>(null)

const DATA_KEY = 'brabu-portal-data'
const NOTIFY_KEY = 'brabu-portal-notifications'
const THEME_KEY = 'brabu-portal-theme'
const UPLOAD_KEY = 'brabu-portal-uploads'
const NOTICE_KEY = 'brabu-portal-notice-overrides'

export const PortalProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [portalData, setPortalDataState] = useState<PortalData>(basePortalData)
  const [theme, setThemeState] = useState<keyof typeof facultyColors>('science')
  const [notifications, setNotifications] = useState<string[]>([
    'Semester 1-2 registration open until 10th August',
  ])
  const [notices, setNotices] = useState<Notice[]>([])
  const [uploads, setUploads] = useState<{ name: string; size: number }[]>([])

  useEffect(() => {
    const stored = localStorage.getItem(DATA_KEY)
    if (stored) {
      setPortalDataState(JSON.parse(stored) as PortalData)
    }
    const storedTheme = localStorage.getItem(THEME_KEY)
    if (storedTheme) {
      setThemeState(storedTheme as keyof typeof facultyColors)
    }
    const storedNotes = localStorage.getItem(NOTIFY_KEY)
    if (storedNotes) {
      setNotifications(JSON.parse(storedNotes) as string[])
    }
    const storedUploads = localStorage.getItem(UPLOAD_KEY)
    if (storedUploads) {
      setUploads(JSON.parse(storedUploads) as { name: string; size: number }[])
    }
    const storedOverrides = localStorage.getItem(NOTICE_KEY)
    if (storedOverrides) {
      setNotices(JSON.parse(storedOverrides) as Notice[])
    }
  }, [])

  useEffect(() => {
    let mounted = true
    const load = () => {
      fetch('/notices.json')
        .then((response) => response.json())
        .then((data: Notice[]) => {
          if (!mounted) return
          setNotices((prev) => {
            if (prev.length > 0) return prev
            return data
          })
        })
        .catch(() => null)
    }
    load()
    const interval = window.setInterval(load, 60000)
    return () => {
      mounted = false
      window.clearInterval(interval)
    }
  }, [])

  useEffect(() => {
    localStorage.setItem(DATA_KEY, JSON.stringify(portalData))
  }, [portalData])

  useEffect(() => {
    localStorage.setItem(NOTIFY_KEY, JSON.stringify(notifications))
  }, [notifications])

  useEffect(() => {
    localStorage.setItem(THEME_KEY, theme)
    const colors = facultyColors[theme]
    document.documentElement.style.setProperty('--accent', colors.accent)
    document.documentElement.style.setProperty('--accent-soft', colors.accentSoft)
  }, [theme])

  useEffect(() => {
    localStorage.setItem(UPLOAD_KEY, JSON.stringify(uploads))
  }, [uploads])

  useEffect(() => {
    if (notices.length > 0) {
      localStorage.setItem(NOTICE_KEY, JSON.stringify(notices))
    }
  }, [notices])

  useEffect(() => {
    const handler = (event: StorageEvent) => {
      if (event.key === NOTICE_KEY && event.newValue) {
        setNotices(JSON.parse(event.newValue) as Notice[])
      }
    }
    window.addEventListener('storage', handler)
    return () => window.removeEventListener('storage', handler)
  }, [])

  const value = useMemo(
    () => ({
      portalData,
      setPortalData: setPortalDataState,
      theme,
      setTheme: setThemeState,
      notifications,
      addNotification: (message: string) =>
        setNotifications((prev) => [message, ...prev].slice(0, 5)),
      removeNotification: (index: number) =>
        setNotifications((prev) => prev.filter((_, idx) => idx !== index)),
      notices,
      broadcastNotice: (notice: Notice) =>
        setNotices((prev) => [notice, ...prev]),
      removeNotice: (id: string) =>
        setNotices((prev) => prev.filter((notice) => notice.id !== id)),
      uploads,
      addUploads: (files: { name: string; size: number }[]) =>
        setUploads((prev) => [...files, ...prev].slice(0, 10)),
    }),
    [portalData, theme, notifications, uploads, notices],
  )

  return <PortalContext.Provider value={value}>{children}</PortalContext.Provider>
}

export const usePortal = () => {
  const context = useContext(PortalContext)
  if (!context) {
    throw new Error('usePortal must be used within PortalProvider')
  }
  return context
}
