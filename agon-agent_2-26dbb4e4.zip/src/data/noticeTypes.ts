export type NoticeCategory = 'exams' | 'campus'
export type NoticePriority = 'critical' | 'info'
export type NoticeTarget = 'science' | 'arts' | 'commerce' | 'all'
export type NoticeIcon = 'exam' | 'result' | 'holiday' | 'update'

export interface Notice {
  id: string
  title: string
  description: string
  category: NoticeCategory
  priority: NoticePriority
  target: NoticeTarget
  timestamp: string
  actionLabel: string
  actionLink: string
  icon: NoticeIcon
}
