export type CourseCategory = 'MJC' | 'MIC' | 'MDC' | 'AEC' | 'SEC' | 'VAC'

export interface Course {
  code: string
  title: string
  description: string
  topics: string[]
}

export interface Semester {
  number: number
  focus: string
  categories: Record<CourseCategory, Course[]>
  mathematicsHighlight?: string
}

export interface Major {
  slug: string
  title: string
  description: string
  semesters: Semester[]
}

export interface Faculty {
  slug: 'science' | 'arts' | 'commerce'
  title: string
  description: string
  majors: Major[]
}

export interface PortalData {
  faculties: Faculty[]
}

export const basePortalData: PortalData = {
  faculties: [
    {
      slug: 'science',
      title: 'Science Faculty',
      description: 'Analytical, experimental, and computational foundations across STEM disciplines.',
      majors: [
        {
          slug: 'mathematics',
          title: 'Mathematics (FYUGP)',
          description: 'Pure and applied mathematics with algebra, calculus, and analysis emphasis.',
          semesters: [
            {
              number: 1,
              focus: 'Foundations of algebra & geometry',
              mathematicsHighlight: String.raw`f(x)=ax^2+bx+c \qquad \Delta=b^2-4ac`,
              categories: {
                MJC: [
                  {
                    code: 'MATH-101',
                    title: 'Algebra I',
                    description: 'Sets, mappings, and group theory fundamentals.',
                    topics: ['Sets & Functions', 'Group Theory', 'Leibniz Theorem'],
                  },
                  {
                    code: 'MATH-102',
                    title: 'Geometry I',
                    description: 'Coordinate geometry with conic sections.',
                    topics: ['Circle & Parabola', 'Ellipse', 'Hyperbola'],
                  },
                ],
                MIC: [
                  {
                    code: 'PHY-101',
                    title: 'Mechanics for Mathematicians',
                    description: 'Classical mechanics with vector calculus.',
                    topics: ['Vectors', 'Newtonian Mechanics', 'Work & Energy'],
                  },
                ],
                MDC: [
                  {
                    code: 'CS-101',
                    title: 'Computational Thinking',
                    description: 'Algorithmic mindset and problem solving.',
                    topics: ['Algorithms', 'Pseudo-code', 'Complexity'],
                  },
                ],
                AEC: [
                  {
                    code: 'ENG-101',
                    title: 'Academic English',
                    description: 'Communication skills for scientific writing.',
                    topics: ['Research Writing', 'Presentations', 'Critical Reading'],
                  },
                ],
                SEC: [
                  {
                    code: 'SEC-101',
                    title: 'Spreadsheet Modeling',
                    description: 'Data modeling using spreadsheets.',
                    topics: ['Formulas', 'Charts', 'Pivot Tables'],
                  },
                ],
                VAC: [
                  {
                    code: 'VAC-101',
                    title: 'Ethics in STEM',
                    description: 'Professional ethics and academic integrity.',
                    topics: ['Plagiarism', 'Responsible AI', 'Academic Honesty'],
                  },
                ],
              },
            },
            {
              number: 2,
              focus: 'Calculus & linear algebra essentials',
              mathematicsHighlight: String.raw`\int_0^1 x^n\,dx=\frac{1}{n+1} \qquad \nabla \cdot \vec{F}`,
              categories: {
                MJC: [
                  {
                    code: 'MATH-201',
                    title: 'Calculus I',
                    description: 'Limits, continuity, and differentiation.',
                    topics: ['Limits', 'Continuity', 'Differentiation'],
                  },
                  {
                    code: 'MATH-202',
                    title: 'Linear Algebra I',
                    description: 'Vector spaces, matrices, and linear transformations.',
                    topics: ['Matrices', 'Vector Spaces', 'Eigenvalues'],
                  },
                ],
                MIC: [
                  {
                    code: 'STAT-201',
                    title: 'Probability Basics',
                    description: 'Foundations of probability theory.',
                    topics: ['Random Variables', 'Distributions', 'Expectation'],
                  },
                ],
                MDC: [
                  {
                    code: 'ENV-201',
                    title: 'Climate Science Overview',
                    description: 'Multidisciplinary climate and sustainability insights.',
                    topics: ['Climate Models', 'Sustainability', 'Policy Basics'],
                  },
                ],
                AEC: [
                  {
                    code: 'HIN-201',
                    title: 'Hindi Communication',
                    description: 'Language fluency for academic discourse.',
                    topics: ['Formal Writing', 'Vocabulary', 'Public Speaking'],
                  },
                ],
                SEC: [
                  {
                    code: 'SEC-201',
                    title: 'Python for Mathematics',
                    description: 'Programming foundations for mathematical modeling.',
                    topics: ['Loops', 'Functions', 'Plotting'],
                  },
                ],
                VAC: [
                  {
                    code: 'VAC-201',
                    title: 'Life Skills & Wellness',
                    description: 'Well-being, time management, and mindfulness.',
                    topics: ['Resilience', 'Time Management', 'Wellness'],
                  },
                ],
              },
            },
            {
              number: 3,
              focus: 'Real analysis and discrete structures',
              mathematicsHighlight: String.raw`\lim_{n\to\infty}\sum_{k=1}^n \frac{1}{n}=1`,
              categories: {
                MJC: [
                  {
                    code: 'MATH-301',
                    title: 'Real Analysis I',
                    description: 'Sequences, series, and convergence.',
                    topics: ['Convergence', 'Uniform Continuity', 'Riemann Integration'],
                  },
                ],
                MIC: [
                  {
                    code: 'CS-301',
                    title: 'Discrete Mathematics',
                    description: 'Logic, combinatorics, and graph theory.',
                    topics: ['Logic', 'Graphs', 'Combinatorics'],
                  },
                ],
                MDC: [
                  {
                    code: 'ECO-301',
                    title: 'Mathematical Economics',
                    description: 'Optimization and modeling for economics.',
                    topics: ['Optimization', 'Game Theory', 'Linear Programming'],
                  },
                ],
                AEC: [
                  {
                    code: 'AEC-301',
                    title: 'Technical Writing',
                    description: 'Reports, documentation, and proposals.',
                    topics: ['Reports', 'Documentation', 'Citation Styles'],
                  },
                ],
                SEC: [
                  {
                    code: 'SEC-301',
                    title: 'Data Visualization',
                    description: 'Visual storytelling with data.',
                    topics: ['Charts', 'Dashboards', 'Storytelling'],
                  },
                ],
                VAC: [
                  {
                    code: 'VAC-301',
                    title: 'Environmental Ethics',
                    description: 'Ethical considerations in sustainability.',
                    topics: ['Sustainability Ethics', 'Policy', 'Case Studies'],
                  },
                ],
              },
            },
            {
              number: 4,
              focus: 'Complex analysis and differential equations',
              mathematicsHighlight: String.raw`e^{i\pi}+1=0`,
              categories: {
                MJC: [
                  {
                    code: 'MATH-401',
                    title: 'Complex Analysis',
                    description: 'Analytic functions and residues.',
                    topics: ['Analytic Functions', 'Residue Theorem', 'Conformal Maps'],
                  },
                  {
                    code: 'MATH-402',
                    title: 'Differential Equations',
                    description: 'ODEs and modeling.',
                    topics: ['First Order ODE', 'Systems', 'Laplace Transform'],
                  },
                ],
                MIC: [
                  {
                    code: 'PHY-401',
                    title: 'Mathematical Physics',
                    description: 'Applications of PDEs in physics.',
                    topics: ['Wave Equation', 'Heat Equation', 'Boundary Value Problems'],
                  },
                ],
                MDC: [
                  {
                    code: 'MDC-401',
                    title: 'Operations Research',
                    description: 'Optimization across disciplines.',
                    topics: ['Optimization Models', 'Simulation', 'Decision Science'],
                  },
                ],
                AEC: [
                  {
                    code: 'AEC-401',
                    title: 'English Literature',
                    description: 'Critical reading and interpretation.',
                    topics: ['Modern Essays', 'Poetry', 'Critique'],
                  },
                ],
                SEC: [
                  {
                    code: 'SEC-401',
                    title: 'Matlab/Octave Lab',
                    description: 'Numerical methods and simulation.',
                    topics: ['Numerical Methods', 'Simulation', 'Matrices'],
                  },
                ],
                VAC: [
                  {
                    code: 'VAC-401',
                    title: 'Community Engagement',
                    description: 'Service learning and outreach.',
                    topics: ['Outreach', 'Leadership', 'Social Impact'],
                  },
                ],
              },
            },
            {
              number: 5,
              focus: 'Abstract algebra and numerical methods',
              mathematicsHighlight: String.raw`\sum_{k=1}^n k = \frac{n(n+1)}{2}`,
              categories: {
                MJC: [
                  {
                    code: 'MATH-501',
                    title: 'Abstract Algebra',
                    description: 'Rings, fields, and modules.',
                    topics: ['Rings', 'Fields', 'Homomorphisms'],
                  },
                ],
                MIC: [
                  {
                    code: 'STAT-501',
                    title: 'Statistical Inference',
                    description: 'Estimation and hypothesis testing.',
                    topics: ['Estimation', 'Testing', 'Regression'],
                  },
                ],
                MDC: [
                  {
                    code: 'MDC-501',
                    title: 'Data Ethics',
                    description: 'Responsible data handling.',
                    topics: ['Privacy', 'Bias', 'Data Governance'],
                  },
                ],
                AEC: [
                  {
                    code: 'AEC-501',
                    title: 'Business Communication',
                    description: 'Professional communication for industry.',
                    topics: ['Emails', 'Meetings', 'Presentations'],
                  },
                ],
                SEC: [
                  {
                    code: 'SEC-501',
                    title: 'Numerical Methods',
                    description: 'Algorithms for numerical computation.',
                    topics: ['Interpolation', 'Integration', 'Error Analysis'],
                  },
                ],
                VAC: [
                  {
                    code: 'VAC-501',
                    title: 'Innovation & Entrepreneurship',
                    description: 'Ideation and startup basics.',
                    topics: ['Idea Validation', 'Business Models', 'Pitching'],
                  },
                ],
              },
            },
            {
              number: 6,
              focus: 'Topology and probability models',
              mathematicsHighlight: String.raw`P(A\cap B)=P(A)P(B|A)` ,
              categories: {
                MJC: [
                  {
                    code: 'MATH-601',
                    title: 'Topology',
                    description: 'Open sets, continuity, and compactness.',
                    topics: ['Topological Spaces', 'Continuity', 'Compactness'],
                  },
                ],
                MIC: [
                  {
                    code: 'CS-601',
                    title: 'Algorithm Design',
                    description: 'Advanced algorithmic techniques.',
                    topics: ['Greedy', 'Dynamic Programming', 'Graph Algorithms'],
                  },
                ],
                MDC: [
                  {
                    code: 'MDC-601',
                    title: 'Research Methodology',
                    description: 'Designing and documenting research.',
                    topics: ['Methodology', 'Literature Review', 'Documentation'],
                  },
                ],
                AEC: [
                  {
                    code: 'AEC-601',
                    title: 'French Basics',
                    description: 'Language skills for global exposure.',
                    topics: ['Grammar', 'Conversation', 'Culture'],
                  },
                ],
                SEC: [
                  {
                    code: 'SEC-601',
                    title: 'Research Computing',
                    description: 'Tools for research workflows.',
                    topics: ['LaTeX', 'Reference Managers', 'Reproducibility'],
                  },
                ],
                VAC: [
                  {
                    code: 'VAC-601',
                    title: 'Civic Responsibility',
                    description: 'Ethics in public life.',
                    topics: ['Civics', 'Policy', 'Community'],
                  },
                ],
              },
            },
            {
              number: 7,
              focus: 'Advanced analysis and electives',
              mathematicsHighlight: String.raw`\zeta(s)=\sum_{n=1}^\infty \frac{1}{n^s}`,
              categories: {
                MJC: [
                  {
                    code: 'MATH-701',
                    title: 'Functional Analysis',
                    description: 'Banach and Hilbert spaces.',
                    topics: ['Normed Spaces', 'Operators', 'Spectral Theory'],
                  },
                ],
                MIC: [
                  {
                    code: 'STAT-701',
                    title: 'Time Series',
                    description: 'Modeling time dependent data.',
                    topics: ['ARIMA', 'Forecasting', 'Seasonality'],
                  },
                ],
                MDC: [
                  {
                    code: 'MDC-701',
                    title: 'Financial Mathematics',
                    description: 'Mathematics for finance.',
                    topics: ['Derivatives', 'Risk', 'Stochastic Models'],
                  },
                ],
                AEC: [
                  {
                    code: 'AEC-701',
                    title: 'German for Academics',
                    description: 'Language for academic collaboration.',
                    topics: ['Vocabulary', 'Reading', 'Presentations'],
                  },
                ],
                SEC: [
                  {
                    code: 'SEC-701',
                    title: 'Capstone Lab',
                    description: 'Project-based learning.',
                    topics: ['Project Management', 'Implementation', 'Presentation'],
                  },
                ],
                VAC: [
                  {
                    code: 'VAC-701',
                    title: 'Leadership Lab',
                    description: 'Leadership skills and teamwork.',
                    topics: ['Team Building', 'Conflict Resolution', 'Strategy'],
                  },
                ],
              },
            },
            {
              number: 8,
              focus: 'Dissertation and industry alignment',
              mathematicsHighlight: String.raw`\mathcal{L}\{f(t)\}=\int_0^\infty e^{-st}f(t)\,dt`,
              categories: {
                MJC: [
                  {
                    code: 'MATH-801',
                    title: 'Dissertation & Viva',
                    description: 'Independent research and thesis.',
                    topics: ['Research', 'Writing', 'Defense'],
                  },
                ],
                MIC: [
                  {
                    code: 'IND-801',
                    title: 'Industry Internship',
                    description: 'Applied learning in industry.',
                    topics: ['Internship', 'Reports', 'Professional Skills'],
                  },
                ],
                MDC: [
                  {
                    code: 'MDC-801',
                    title: 'Interdisciplinary Seminar',
                    description: 'Cross-domain presentations.',
                    topics: ['Seminar', 'Critical Feedback', 'Publishing'],
                  },
                ],
                AEC: [
                  {
                    code: 'AEC-801',
                    title: 'Academic Publishing',
                    description: 'Publishing process and ethics.',
                    topics: ['Publishing', 'Peer Review', 'Citation Ethics'],
                  },
                ],
                SEC: [
                  {
                    code: 'SEC-801',
                    title: 'Professional Portfolio',
                    description: 'Showcase of academic achievements.',
                    topics: ['Portfolio', 'Personal Branding', 'LinkedIn'],
                  },
                ],
                VAC: [
                  {
                    code: 'VAC-801',
                    title: 'Social Innovation',
                    description: 'Impact-driven solutions.',
                    topics: ['Innovation', 'Impact Metrics', 'Sustainability'],
                  },
                ],
              },
            },
          ],
        },
        {
          slug: 'physics',
          title: 'Physics',
          description: 'Core physics with computational labs and research practice.',
          semesters: [
            {
              number: 1,
              focus: 'Mechanics & lab practice',
              categories: {
                MJC: [
                  {
                    code: 'PHY-101',
                    title: 'Classical Mechanics',
                    description: 'Newtonian mechanics and kinematics.',
                    topics: ['Kinematics', 'Dynamics', 'Energy'],
                  },
                ],
                MIC: [
                  {
                    code: 'MATH-101',
                    title: 'Mathematical Methods',
                    description: 'Math tools for physicists.',
                    topics: ['Vectors', 'Differential Equations', 'Linear Algebra'],
                  },
                ],
                MDC: [
                  {
                    code: 'CHE-101',
                    title: 'Physical Chemistry',
                    description: 'Thermodynamics & kinetics.',
                    topics: ['Thermo', 'Phase Equilibria', 'Kinetics'],
                  },
                ],
                AEC: [
                  {
                    code: 'ENG-101',
                    title: 'Academic English',
                    description: 'Communication for science.',
                    topics: ['Writing', 'Reading', 'Presentations'],
                  },
                ],
                SEC: [
                  {
                    code: 'SEC-101',
                    title: 'Physics Lab Skills',
                    description: 'Instrumentation and safety.',
                    topics: ['Instrumentation', 'Lab Safety', 'Reporting'],
                  },
                ],
                VAC: [
                  {
                    code: 'VAC-101',
                    title: 'Scientific Ethics',
                    description: 'Ethics in experimentation.',
                    topics: ['Integrity', 'Safety', 'Compliance'],
                  },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      slug: 'arts',
      title: 'Arts Faculty',
      description: 'Humanities and social sciences with critical thinking and creativity.',
      majors: [
        {
          slug: 'english',
          title: 'English Literature',
          description: 'Literary studies, criticism, and writing.',
          semesters: [
            {
              number: 1,
              focus: 'Foundations of literature',
              categories: {
                MJC: [
                  {
                    code: 'ENG-101',
                    title: 'Classical Literature',
                    description: 'Epic, drama, and poetry traditions.',
                    topics: ['Epic', 'Drama', 'Poetry'],
                  },
                ],
                MIC: [
                  {
                    code: 'HIS-101',
                    title: 'World Civilizations',
                    description: 'Global historical narratives.',
                    topics: ['Ancient History', 'Medieval', 'Modern'],
                  },
                ],
                MDC: [
                  {
                    code: 'SOC-101',
                    title: 'Sociology Basics',
                    description: 'Society and institutions.',
                    topics: ['Culture', 'Institutions', 'Social Change'],
                  },
                ],
                AEC: [
                  {
                    code: 'HIN-101',
                    title: 'Hindi Communication',
                    description: 'Language proficiency.',
                    topics: ['Grammar', 'Writing', 'Speaking'],
                  },
                ],
                SEC: [
                  {
                    code: 'SEC-101',
                    title: 'Creative Writing Lab',
                    description: 'Workshops for fiction and poetry.',
                    topics: ['Fiction', 'Poetry', 'Editing'],
                  },
                ],
                VAC: [
                  {
                    code: 'VAC-101',
                    title: 'Value Education',
                    description: 'Ethics and civic values.',
                    topics: ['Ethics', 'Civic Duties', 'Social Responsibility'],
                  },
                ],
              },
            },
          ],
        },
        {
          slug: 'history',
          title: 'History',
          description: 'Historical analysis with research methodology.',
          semesters: [
            {
              number: 1,
              focus: 'World history overview',
              categories: {
                MJC: [
                  {
                    code: 'HIS-101',
                    title: 'Ancient Civilizations',
                    description: 'Early societies and empires.',
                    topics: ['Mesopotamia', 'Indus Valley', 'Egypt'],
                  },
                ],
                MIC: [
                  {
                    code: 'POL-101',
                    title: 'Political Theory',
                    description: 'Political ideas and governance.',
                    topics: ['Democracy', 'State', 'Rights'],
                  },
                ],
                MDC: [
                  {
                    code: 'ECO-101',
                    title: 'Economics for Society',
                    description: 'Economic principles for humanities.',
                    topics: ['Microeconomics', 'Macro Basics', 'Markets'],
                  },
                ],
                AEC: [
                  {
                    code: 'AEC-101',
                    title: 'Academic Writing',
                    description: 'Essay structure and citations.',
                    topics: ['Research', 'Citations', 'Critical Writing'],
                  },
                ],
                SEC: [
                  {
                    code: 'SEC-101',
                    title: 'Archival Methods',
                    description: 'Handling historical records.',
                    topics: ['Archives', 'Preservation', 'Cataloging'],
                  },
                ],
                VAC: [
                  {
                    code: 'VAC-101',
                    title: 'Cultural Heritage',
                    description: 'Understanding heritage preservation.',
                    topics: ['Heritage', 'Conservation', 'Community'],
                  },
                ],
              },
            },
          ],
        },
      ],
    },
    {
      slug: 'commerce',
      title: 'Commerce Faculty',
      description: 'Financial literacy, business strategy, and market-oriented skills.',
      majors: [
        {
          slug: 'accounting',
          title: 'Financial Accounting',
          description: 'Accounting practices and financial reporting.',
          semesters: [
            {
              number: 1,
              focus: 'Accounting principles & business basics',
              categories: {
                MJC: [
                  {
                    code: 'ACC-101',
                    title: 'Financial Accounting I',
                    description: 'Journal entries, ledgers, and trial balance.',
                    topics: ['Journal Entries', 'Ledger', 'Financial Statements'],
                  },
                ],
                MIC: [
                  {
                    code: 'MATH-101',
                    title: 'Business Mathematics',
                    description: 'Quantitative techniques for commerce.',
                    topics: ['Percentages', 'Interest', 'Matrices'],
                  },
                ],
                MDC: [
                  {
                    code: 'ECO-101',
                    title: 'Microeconomics',
                    description: 'Demand, supply, and market equilibrium.',
                    topics: ['Demand', 'Supply', 'Elasticity'],
                  },
                ],
                AEC: [
                  {
                    code: 'AEC-101',
                    title: 'Business Communication',
                    description: 'Professional communication skills.',
                    topics: ['Reports', 'Presentations', 'Email Etiquette'],
                  },
                ],
                SEC: [
                  {
                    code: 'SEC-101',
                    title: 'Tally & Accounting Software',
                    description: 'Accounting tools and software.',
                    topics: ['Tally', 'GST Entries', 'Inventory'],
                  },
                ],
                VAC: [
                  {
                    code: 'VAC-101',
                    title: 'Corporate Ethics',
                    description: 'Ethics in business practices.',
                    topics: ['Ethics', 'Governance', 'Compliance'],
                  },
                ],
              },
            },
          ],
        },
        {
          slug: 'management',
          title: 'Business Management',
          description: 'Operations, marketing, and strategic leadership.',
          semesters: [
            {
              number: 1,
              focus: 'Principles of management',
              categories: {
                MJC: [
                  {
                    code: 'MGT-101',
                    title: 'Management Principles',
                    description: 'Planning, organizing, and leadership.',
                    topics: ['Planning', 'Organizing', 'Leadership'],
                  },
                ],
                MIC: [
                  {
                    code: 'PSY-101',
                    title: 'Organizational Psychology',
                    description: 'Human behavior at work.',
                    topics: ['Motivation', 'Teams', 'Culture'],
                  },
                ],
                MDC: [
                  {
                    code: 'LAW-101',
                    title: 'Business Law',
                    description: 'Legal framework for commerce.',
                    topics: ['Contracts', 'Compliance', 'IP'],
                  },
                ],
                AEC: [
                  {
                    code: 'AEC-101',
                    title: 'Professional English',
                    description: 'Corporate communication skills.',
                    topics: ['Writing', 'Negotiation', 'Public Speaking'],
                  },
                ],
                SEC: [
                  {
                    code: 'SEC-101',
                    title: 'Excel for Managers',
                    description: 'Analytics with spreadsheets.',
                    topics: ['Formulas', 'Dashboards', 'Reporting'],
                  },
                ],
                VAC: [
                  {
                    code: 'VAC-101',
                    title: 'Leadership Ethics',
                    description: 'Ethics in leadership.',
                    topics: ['Integrity', 'Decision Making', 'Accountability'],
                  },
                ],
              },
            },
          ],
        },
      ],
    },
  ],
}

export const facultyColors: Record<string, { accent: string; accentSoft: string }>
  = {
  science: { accent: '#3b82f6', accentSoft: '#1e293b' },
  arts: { accent: '#d97706', accentSoft: '#78350f' },
  commerce: { accent: '#059669', accentSoft: '#064e3b' },
}
